from django.urls import path
from . import views, utility


urlpatterns = [
    path('booking/', views.create_order),
    path('booking/book/', views.book),
    path('my-orders/', views.pending_orders),
    path('login/', views.login_view),
    path('dashboard/', views.dashboard),
    path('labels/', views.labels_page),
    path('recharge/', views.recharge),
    path('download-labels/', views.download_labels),
    path('orders/', views.all_orders),
    path('pincode/', views.pincode),
    path('get_city_state/', views.get_city_state, name='get_city_state')
]