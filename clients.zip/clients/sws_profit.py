from google.oauth2 import service_account
from googleapiclient.discovery import build
from datetime import datetime

# Path to your service account JSON file
SERVICE_ACCOUNT_FILE = "C:\\Users\\Supriyo\\Desktop\\OdinBeast\\sws-profit-tracker-8b482d5cc006.json"

# Define the scope
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# Google Sheet ID
SPREADSHEET_ID = '1yoculkgiSX1kFFWpns5664GyCEKh7FBkJRlLjl8CnQo'

def get_current_sheet_name():
    """Returns the sheet name for the current month and year."""
    now = datetime.now()
    return now.strftime("%B %y")  # Example: 'September 24'

def get_previous_sheet_name():
    """Returns the sheet name for the previous month and year."""
    now = datetime.now()
    # Calculate previous month
    month = now.month - 1 if now.month > 1 else 12
    year = now.year if now.month > 1 else now.year - 1
    previous_date = datetime(year, month, 1)
    return previous_date.strftime("%B %y")  # Example: 'August 24'

def create_sheet_if_not_exists(sheet_service, sheet_name):
    """Checks if a sheet with the given name exists; if not, creates it with formatting copied from the previous month."""
    # Get all sheets in the spreadsheet
    sheet_metadata = sheet_service.get(spreadsheetId=SPREADSHEET_ID).execute()
    sheets = sheet_metadata.get('sheets', '')

    sheet_exists = any(sheet.get("properties", {}).get("title") == sheet_name for sheet in sheets)

    if not sheet_exists:
        previous_sheet_name = get_previous_sheet_name()
        previous_sheet_id = None

        # Find the ID of the previous month's sheet
        for sheet in sheets:
            if sheet.get("properties", {}).get("title") == previous_sheet_name:
                previous_sheet_id = sheet.get("properties", {}).get("sheetId")
                break

        if previous_sheet_id is not None:
            # Create a new sheet with the formatting of the previous month
            body = {
                'requests': [
                    {
                        'duplicateSheet': {
                            'sourceSheetId': previous_sheet_id,
                            'insertSheetIndex': len(sheets),
                            'newSheetName': sheet_name
                        }
                    }
                ]
            }
            sheet_service.batchUpdate(spreadsheetId=SPREADSHEET_ID, body=body).execute()

            # Get the new sheet's ID
            new_sheet_metadata = sheet_service.get(spreadsheetId=SPREADSHEET_ID).execute()
            new_sheet = next((s for s in new_sheet_metadata.get('sheets', []) if s.get("properties", {}).get("title") == sheet_name), None)
            new_sheet_id = new_sheet.get("properties", {}).get("sheetId")

            # Clear the data in the new sheet's working range "A2:E" to preserve headers
            if new_sheet_id is not None:
                clear_ranges = [f'{sheet_name}!A2:E', f'{sheet_name}!F32:H37']
                for clear_range in clear_ranges:
                    sheet_service.values().clear(spreadsheetId=SPREADSHEET_ID, range=clear_range).execute()

def append_to_google_sheet_for_sws_profit(date, booker, company_charge, my_charge):
    # Calculate "My Profit"
    my_profit = my_charge - company_charge

    # Authenticate using service account
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    
    # Build the Sheets API service
    service = build('sheets', 'v4', credentials=creds)
    
    # Get the current month's sheet name
    sheet_name = get_current_sheet_name()
    
    # Ensure the sheet exists
    create_sheet_if_not_exists(service.spreadsheets(), sheet_name)
    
    # Define the range where data will be appended
    range_name = f'{sheet_name}!A:E'
    
    # Prepare the data to be added to the sheet
    values = [
        [date, booker, company_charge, my_charge, my_profit]
    ]
    
    body = {
        'values': values
    }
    
    # Call the Sheets API to append the data
    result = service.spreadsheets().values().append(
        spreadsheetId=SPREADSHEET_ID,
        range=range_name,
        valueInputOption='USER_ENTERED',
        body=body
    ).execute()
    

# Example usage
# append_to_google_sheet('01/09/2024', 'Achintaya', 62, 72)
