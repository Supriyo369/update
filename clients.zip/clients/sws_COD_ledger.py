from google.oauth2 import service_account
from googleapiclient.discovery import build
from datetime import datetime

# Path to your service account JSON file
SERVICE_ACCOUNT_FILE = "C:\\Users\\Supriyo\\Desktop\\OdinBeast\\sws-profit-tracker-8b482d5cc006.json"

# Define the scope
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# Google Sheet ID
SPREADSHEET_ID = '1Pa588p6aLcRT-W9Z8fQ3sheCs5U_98i9SqRRHBJLcQ0'


def append_to_google_sheet_for_COD(date, seller, customer_name, cod_amount, seller_mob_no):


    # Authenticate using service account
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    
    # Build the Sheets API service
    service = build('sheets', 'v4', credentials=creds)
    
    # Define the range where data will be appended
    range_name = 'Sheet1!A:E'
    
    # Prepare the data to be added to the sheet
    values = [
        [date, seller, customer_name, cod_amount, seller_mob_no]
    ]
    
    body = {
        'values': values
    }
    
    # Call the Sheets API to append the data
    result = service.spreadsheets().values().append(
        spreadsheetId=SPREADSHEET_ID,
        range=range_name,
        valueInputOption='USER_ENTERED',
        body=body
    ).execute()
    

# Example usage
# append_to_google_sheet_for_COD('01/09/2024', 'Achintaya', 'Supriyo Chowdhury', 1450, 8597861168)
