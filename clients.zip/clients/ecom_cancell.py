import requests

awb_no = int(input("Please Enter Ecom Express AWB no to be cancelled: "))


def shipment_cancel(awb):
    url = "https://api.ecomexpress.in/apiv2/cancel_awb/?="
    payload={'username': 'SUPRIYOCHOWDHURY229756',
    'password': 'A0H8FTfAE6',
    'awbs': awb}
    files=[]
    headers = {}
    response = requests.request("POST", url, headers=headers, data=payload, files=files)
    print(response.text)


shipment_cancel(awb_no)