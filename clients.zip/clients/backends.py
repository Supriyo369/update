from django.db import models
from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.hashers import make_password



class Clients(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    wallet = models.DecimalField(max_digits=10, decimal_places=2)
    total_company_charge =models.DecimalField(max_digits=10, decimal_places=2)
    total_sws_charge = models.DecimalField(max_digits=10, decimal_places=2)
    total_sws_profit = models.DecimalField(max_digits=10, decimal_places=2)

    pickup_address = models.CharField(max_length=500)
    pickup_state = models.CharField(max_length=100)
    pickup_city = models.CharField(max_length=100)
    phone = models.BigIntegerField()
    pincode = models.IntegerField()
    joined_on = models.CharField(max_length=20)

    def formatted_joined_on(self):
        return self.joined_on.strftime('%d/%m/%Y %I:%M %p')


    def __str__(self):
        return self.name + ' | ' + self.username


class Orders(models.Model):
    order_id = models.BigIntegerField()
    username = models.CharField(max_length=100)
    booked_by = models.CharField(max_length=300)
    booked_by_raw_name = models.CharField(max_length=300)
    booked_mob_no = models.CharField(max_length=300)
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=300)
    pincode = models.CharField(max_length=6)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    phone = models.BigIntegerField(null=True, blank=True)
    alt_phone = models.BigIntegerField(blank=True, null=True)
    length = models.DecimalField(max_digits=10, decimal_places=2)
    width = models.DecimalField(max_digits=10, decimal_places=2)
    height = models.DecimalField(max_digits=10, decimal_places=2)
    weight = models.DecimalField(max_digits=10, decimal_places=2)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    mode_of_payment = models.CharField(max_length=7)
    is_shipped = models.BooleanField(default=False)
    awb = models.CharField(max_length=20)
    company_charge = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    sws_charge = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    sws_profit = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)

    created_on = models.CharField(max_length=20)


    def __str__(self):
        return self.booked_by + " " + self.name


class CustomBackend(BaseBackend):
    def authenticate(self, request, username=None, password=None):
        try:
            client = Clients.objects.get(username=username)
            if client.password == password:  # Plain text password check
                user, created = User.objects.get_or_create(username=username)
                if created:
                    user.set_password(make_password(password))  # Set password to hashed format
                    user.save()
                return user
            else:
                return None
        except Clients.DoesNotExist:
            return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None




class Base_Pricing(models.Model):
    within_state_0_5 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_0_5 = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_1000 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_1000 = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_1500 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_1500 = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_2000 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_2000 = models.DecimalField(max_digits=6, decimal_places=2)
    cod_charge = models.DecimalField(max_digits=6, decimal_places=2)
    special_states = models.DecimalField(max_digits=6, decimal_places=2)



class UserCustomPricing(models.Model):
    username = models.CharField(max_length=100)
    within_state_0_5 = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_0_5_COD = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_0_5 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_0_5_COD = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_1000 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_1000 = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_1500 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_1500 = models.DecimalField(max_digits=6, decimal_places=2)
    within_state_2000 = models.DecimalField(max_digits=6, decimal_places=2)
    outside_state_2000 = models.DecimalField(max_digits=6, decimal_places=2)
    cod_charge = models.DecimalField(max_digits=6, decimal_places=2)
    special_states = models.DecimalField(max_digits=6, decimal_places=2)



class Centralized(models.Model):
    order_id = models.BigIntegerField()