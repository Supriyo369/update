import requests, json



def token():
    get_token = requests.post('https://shipment.xpressbees.com/api/users/login', json={"email": "demo@xpressbees.com", "password": "demo@123"}).json()
    bearer_token2 = get_token['data']
    return bearer_token2


def dateTime():
    import datetime
    return datetime.datetime.now().strftime("%d/%m/%Y, %I:%M %p")

print(dateTime())
