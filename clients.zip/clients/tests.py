from django.test import TestCase

import requests, json



def btoken():
    get_token = requests.post('https://shipment.xpressbees.com/api/users/login', json={"email": "demo@xpressbees.com", "password": "demo@123"}).json()
    bearer_token2 = get_token['data']
    return bearer_token2


def company_rates(origin, destinatio, payment_type, order_amount, weight):
    bearer_token = btoken()
    url = "https://shipment.xpressbees.com/api/courier/serviceability"
    payload = {
        "origin": origin,
        "destination": destinatio,
        "payment_type": payment_type,
        "order_amount": order_amount,
        "weight": int(weight),
    }
    response = requests.post(url, headers={"Authorization": f"Bearer {bearer_token}"}, json=payload).text
    data = json.loads(response)['data']
    min_freight_charges = float('inf')
    min_freight_info = {}
    for item in data:
        if item['freight_charges'] < min_freight_charges:
            min_freight_charges = item['freight_charges']
            min_freight_info = {'id': item['id'], 'name': item['name'], 'charge': item['freight_charges']}
    print(min_freight_info)
    # print(data)
    return min_freight_info

company_rates(700056, 731127, 'prepaid', '350', 2000)