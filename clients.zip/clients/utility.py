import requests
import json
from django.core.cache import cache
from .backends import UserCustomPricing, Base_Pricing
from decimal import Decimal

# Constants
TOKEN_URL = 'https://shipment.xpressbees.com/api/users/login'
SERVICEABILITY_URL = 'https://shipment.xpressbees.com/api/courier/serviceability'
SPECIAL_STATES = [
    "Arunachal Pradesh", "Assam", "Manipur", "Meghalaya", 
    "Mizoram", "Nagaland", "Tripura", "Sikkim"
]
COD_THRESHOLD = Decimal('3000')
COD_RATE = Decimal('0.02')

# Caching token to avoid repetitive API calls
def btoken():
    token = cache.get('xpressbees_token')
    if not token:
        get_token = requests.post(TOKEN_URL, json={"email": "supriyochowdhury001@gmail.com", "password": "Supriyo"}).json()
        token = get_token['data']
        cache.set('xpressbees_token', token, timeout=10500)  
    return token

def company_rates(origin, destinatio, payment_type, order_amount, weight):
    bearer_token = btoken()
    url = SERVICEABILITY_URL
    payload = {
        "origin": origin,
        "destination": destinatio,
        "payment_type": payment_type,
        "order_amount": order_amount,
        "weight": int(weight),
    }
    response = requests.post(url, headers={"Authorization": f"Bearer {bearer_token}"}, json=payload).text
    data = json.loads(response)['data']
    
    min_freight_info = min(data, key=lambda x: x['total_charges'], default={})
    return {
        'id': min_freight_info.get('id'),
        'name': min_freight_info.get('name'),
        'charge': min_freight_info.get('total_charges', float('inf'))
    }

def sws_pricing_logic(pricing_source, pickup_state, delivery_state, type, weight_category, order_amount):
    if pickup_state == delivery_state:
        price = getattr(pricing_source, f'within_state_{weight_category}')
    elif delivery_state in SPECIAL_STATES:
        price = pricing_source.special_states
    else:
        price = getattr(pricing_source, f'outside_state_{weight_category}')
    
    if type != 'prepaid':
        order_amount = Decimal(order_amount)
        if order_amount > COD_THRESHOLD:
            price += order_amount * COD_RATE
        else:
            price += pricing_source.cod_charge

    return price

def sws_pricing(username, pickup_state, delivery_state, type, weight_category, order_amount):
    try:
        user_pricing = UserCustomPricing.objects.get(username=username)
        return sws_pricing_logic(user_pricing, pickup_state, delivery_state, type, weight_category, order_amount)
    except UserCustomPricing.DoesNotExist:
        base_price = Base_Pricing.objects.all()[0]
        return sws_pricing_logic(base_price, pickup_state, delivery_state, type, weight_category, order_amount)

def sws_charge(username, weight, pickup_state, delivery_state, type, price):
    weight = int(weight)
    if weight <= 500:
        return sws_pricing(username, pickup_state, delivery_state, type, '0_5', price)
    elif weight <= 1000:
        return sws_pricing(username, pickup_state, delivery_state, type, '1000', price)
    elif weight <= 1500:
        return sws_pricing(username, pickup_state, delivery_state, type, '1500', price)
    elif weight <= 2000:
        return sws_pricing(username, pickup_state, delivery_state, type, '2000', price)
    elif weight > 2000:
        return None
