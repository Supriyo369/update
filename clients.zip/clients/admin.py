from django.contrib import admin
from .backends import *


admin.site.register([Clients, Orders, Base_Pricing, UserCustomPricing, Centralized])