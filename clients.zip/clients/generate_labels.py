from django.http import HttpResponse
from django.shortcuts import render
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Frame
from barcode import Code128
from barcode.writer import ImageWriter
from io import BytesIO
from reportlab.lib.utils import ImageReader
from PIL import Image
import os

# Constants
PAGE_WIDTH, PAGE_HEIGHT = A4
MARGIN = 5 * mm
LABEL_WIDTH = (PAGE_WIDTH - 2 * MARGIN) / 2 - 5 * mm
LABEL_HEIGHT = (PAGE_HEIGHT - 2 * MARGIN) / 2 - 5 * mm
LABEL_SPACING = 5 * mm
TEXT_MARGIN = 5 * mm
LOGO_WIDTH = 35 * mm
LOGO_HEIGHT = 25 * mm
COURIER_LOGO_PATH = "C:/Users/Supriyo/Desktop/Labels/Code/sws.png"  # Adjust this path if your logo is in a different location

def generate_barcode(data):
    """Generate a barcode image in-memory."""
    barcode = Code128(data, writer=ImageWriter())
    barcode_io = BytesIO()
    barcode.write(barcode_io, options={'module_height': 10.0, 'module_width': 0.5})
    barcode_io.seek(0)
    return Image.open(barcode_io)

def create_label(c, x, y, shipping_address, barcode_data, from_address):
    """Create a single label at position (x, y)."""
    # Draw a rectangle for the label border
    c.rect(x, y, LABEL_WIDTH, LABEL_HEIGHT)

    # Shipping Address
    address_width = LABEL_WIDTH - LOGO_WIDTH - 2 * TEXT_MARGIN  # Adjust address width to avoid overlapping the logo
    address_text = "<br/>".join(shipping_address)
    address_style = getSampleStyleSheet()["Normal"]
    address_paragraph = Paragraph(address_text, address_style)
    address_frame = Frame(x + TEXT_MARGIN, y + LABEL_HEIGHT - 110, address_width, 100, leftPadding=0, bottomPadding=0, rightPadding=0, topPadding=0)
    address_frame.addFromList([address_paragraph], c)

    # Add the courier logo next to the shipping address
    logo_x = x + LABEL_WIDTH - TEXT_MARGIN - LOGO_WIDTH + 10
    logo_y = y + LABEL_HEIGHT - LOGO_HEIGHT - TEXT_MARGIN
    c.drawImage(COURIER_LOGO_PATH, logo_x, logo_y, width=LOGO_WIDTH, height=LOGO_HEIGHT, preserveAspectRatio=True)

    # Draw a line under the courier logo
    line_y = y + LABEL_HEIGHT - LOGO_HEIGHT - TEXT_MARGIN - 20  # Slightly below the logo
    c.line(x, line_y, x + LABEL_WIDTH, line_y)  # Line from left edge to right edge


    # Static "Thank you" text
    c.setFont("Helvetica", 10)
    c.drawRightString(x + LABEL_WIDTH - TEXT_MARGIN, y + LABEL_HEIGHT - 250, "Thank you for your purchase")

    # From Address
    c.setFont("Helvetica", 10)
    from_y = y + LABEL_HEIGHT - 270
    for line in from_address:
        c.drawRightString(x + LABEL_WIDTH - TEXT_MARGIN, from_y, line)
        from_y -= 12

    # Generate the barcode and convert it to ImageReader
    barcode_img = generate_barcode(barcode_data)
    barcode_img_io = BytesIO()
    barcode_img.save(barcode_img_io, format='PNG')
    barcode_img_io.seek(0)
    barcode_img_reader = ImageReader(barcode_img_io)
    
    # Draw the barcode image on the canvas
    c.drawImage(barcode_img_reader, x + TEXT_MARGIN, y + TEXT_MARGIN + 160, width=LABEL_WIDTH - 2 * TEXT_MARGIN, height=70, preserveAspectRatio=True)

    # Draw a line under the barcode
    barcode_line_y = y + TEXT_MARGIN + 150  # Slightly above where the barcode starts
    c.line(x, barcode_line_y, x + LABEL_WIDTH, barcode_line_y)  # Line from left edge to right edge

def generate_shipping_labels(labels_data, filename='shipping_labels.pdf'):
    """
    Generate a PDF with multiple shipping labels.
    
    :param labels_data: List of dictionaries containing label information.
    :param filename: The output PDF filename.
    :return: The generated PDF filename.
    """
    c = canvas.Canvas(filename, pagesize=A4)
    
    for index, label_data in enumerate(labels_data):
        # Determine label position based on index
        position = index % 4
        x = MARGIN + (position % 2) * (LABEL_WIDTH + LABEL_SPACING)
        y = PAGE_HEIGHT - MARGIN - (position // 2) * (LABEL_HEIGHT + LABEL_SPACING) - LABEL_HEIGHT
        
        # Create the shipping address with line breaks
        shipping_address = [
            "To,",    # Line 1: "To,"
            label_data['to_name'],  # Line 2: Customer name
            label_data['address_line']  # Line 3: Shipping address
        ]
        if label_data['mop'] == "cod":
            c.setFont("Helvetica-Bold", 15)
            c.drawCentredString(x + LABEL_WIDTH / 2, y + LABEL_HEIGHT - 140, f'COD: {label_data['price']}')
        else:
            c.setFont("Helvetica-Bold", 15)
            c.drawCentredString(x + LABEL_WIDTH / 2, y + LABEL_HEIGHT - 140, 'PREPAID')
            
        # From address with line break after "From," and sender's mobile number
        from_address = [
            "From,",  # Line 1: "From,"
            label_data['from_name'],  # Line 2: Sender name
            label_data['from_mob']  # Line 3: Sender mobile number
        ]
        
        # Create label at the calculated position
        create_label(c, x, y, shipping_address, label_data['barcode_data'], from_address)
        
        # If this is the fourth label or the last label, move to a new page
        if (position == 3) or (index == len(labels_data) - 1):
            c.showPage()
    
    # Save the PDF file
    c.save()
    return filename

def cleanup_files(filename):
    """Remove the generated files."""
    try:
        os.remove(filename)
    except Exception as e:
        print(f'Error removing file: {e}')

